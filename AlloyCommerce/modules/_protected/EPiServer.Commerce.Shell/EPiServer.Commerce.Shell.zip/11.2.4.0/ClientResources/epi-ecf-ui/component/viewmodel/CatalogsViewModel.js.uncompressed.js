﻿define("epi-ecf-ui/component/viewmodel/CatalogsViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi-cms/asset/view-model/HierarchicalListViewModel",
// Commerce
    "../../command/NavigateToEditPage",
    "../../command/ShowCatalogThumbnails",
    "../../widget/viewmodel/CatalogTreeStoreModel"
],

function (
// dojo
    declare,
    lang,
    when,
// epi
    HierarchicalListViewModel,
// Commerce
    NavigateToEditPageCommand,
    ShowCatalogThumbnailsCommand,
    CatalogTreeStoreModel
) {
    // module:
    //      epi-ecf-ui.component.viewmodel.CatalogsViewModel

    return declare([HierarchicalListViewModel], {
        // summary:
        //      Catalogs view model.
        // tags:
        //      public

        treeStoreModelClass: CatalogTreeStoreModel,

        // showCatalogThumbnails: [public] Boolean
        //      Flag which indicates whether to show thumbnails in catalog hierarchical list. Value is true if thumbnails should be shown; otherwise false.
        showCatalogThumbnails: true,

        postscript: function () {
            this.inherited(arguments);

            this.set("commands", [new ShowCatalogThumbnailsCommand({ model: this })]);
        },

        startup: function () {
            this.inherited(arguments);

            // if navigateOnEdit is true, let's replace the edit command to NavigateToEditPageCommand
            // so when editing the content, the browser will navigate to edit page instead of changing context.
            if (this.get("navigateOnEdit")) {
                this._commandRegistry.edit.command = new NavigateToEditPageCommand({ category: "context" });
            }
        },

        destroy: function () {
            this.inherited(arguments);

            this.get("treeStoreModel").destroy();
        },

        _showCatalogThumbnailsSetter: function (value) {
            // summary:
            //      Set the show catalog thumbnails property.
            // tags:
            //      protected

            this.showCatalogThumbnails = value;
        },

        _getSortSettings: function () {
            // summary:
            //      Returns the list of sort criteria.
            // tags:
            //      protected override

            // overwrite to return empty sort setting, which means that the default content's sort order will be used.
            return [];
        },

        contentContextChanged: function (context, callerData) {
            // summary:
            //      Called when the currently loaded content changes. I.e. a new content data object is loaded into the preview area.
            //      Override _ContextContextMixin.contentContextChanged
            // tags:
            //      protected override

            // If the list already has a context, don't change it
            var oldListRef = this.get("currentListItem");
            if (oldListRef) {
                return;
            }

            // If not, let the base implementation set up the initial context
            this.inherited(arguments);
        },

        _listQuerySetter: function (value) {
            // summary:
            //      Custom setter for the list query to create a different query depending
            //      on if the item supports sorting of children.
            // tags:
            //      private

            if (!value) {
                this.listQuery = value;
                return;
            }

            when(this.store.get(value.referenceId), lang.hitch(this, function (item) {
                var supportSorting = !!item && !!item.capabilities && !!item.capabilities.sortChildren,
                    listQuery = lang.delegate(value, { simplified: !supportSorting });
                this.listQuery = listQuery;
            }));
        }
    });
});