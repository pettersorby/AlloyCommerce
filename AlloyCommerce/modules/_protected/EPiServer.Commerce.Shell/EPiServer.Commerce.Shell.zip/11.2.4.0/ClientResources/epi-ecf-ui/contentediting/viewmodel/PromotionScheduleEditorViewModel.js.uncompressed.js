﻿define("epi-ecf-ui/contentediting/viewmodel/PromotionScheduleEditorViewModel", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/when",
    "dojo/string",

    "epi/datetime",
    "epi/dependency"
], function (
    array,
    declare,
    lang,
    Stateful,
    when,
    string,

    epiDate,
    dependency
) {
    return declare([Stateful], {
        // module:
        //  epi-ecf-ui/contentediting/viewmodel/PromotionScheduleEditorViewModel
        // summary:
        //    Represents the view model for Promotion schedule editor widget.
        // tags:
        //    public

        store: null,

        constraints: null,

        campaignDateText: null,

        value: null,

        postscript: function () {
            this.inherited(arguments);

            if (!this.store) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get("epi.cms.contentdata");
            }
        },

        _formatDate: function (datetime) {
            // summary:
            //      Format datetime to short type.
            // datetime: Object
            //      The raw data.
            // tags:
            //      public

            return datetime && datetime !== "" ? epiDate.toUserFriendlyString(datetime) : "";
        },

        _valueSetter: function (value) {
            this.set("validFrom", value ? value.validFrom : null);
            this.set("validUntil", value ? value.validUntil : null);
            this.set("useCampaignDate", value && !!value.useCampaignDate);
            this.set("campaignLink", value ? value.campaignLink : null);

            if (value && value.campaignLink && this.store) {
                when(this.store.refresh(value.campaignLink), lang.hitch(this, function (content) {
                    if (content && content.properties) {
                        this._updateCampaignDate(content.properties.validFrom, content.properties.validUntil);
                    }
                }));
            }
        },

        _updateCampaignDate: function (validFrom, validUntil) {
            this.set("constraints", {
                min: validFrom ? new Date(validFrom) : null,
                max: validUntil ? new Date(validUntil) : null
            });
            this.set("campaignDateText", string.substitute("(${validFrom} to ${validUntil})", {
                validFrom: validFrom ? this._formatDate(validFrom) : "-",
                validUntil: validUntil ? this._formatDate(validUntil) : "-"
            }));
        },

        _valueGetter: function () {
            return {
                useCampaignDate: this.get("useCampaignDate"),
                validUntil: this.get("validUntil"),
                validFrom: this.get("validFrom"),
                campaignLink: this.get("campaignLink")
            };
        }
    });
});
