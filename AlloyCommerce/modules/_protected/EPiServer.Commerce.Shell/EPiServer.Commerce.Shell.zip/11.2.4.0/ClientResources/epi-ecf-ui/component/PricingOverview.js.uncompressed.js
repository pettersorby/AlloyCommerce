require({cache:{
'url:epi-ecf-ui/component/templates/PricingOverview.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-type=\"epi-ecf-ui/widget/PricingOverview\" data-dojo-attach-point=\"overviewWidget\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/component/PricingOverview", [
// dojo
    "dojo/_base/declare",
// commerce
    "./_OverviewBase",
// resources
    "dojo/text!./templates/PricingOverview.html",
    "epi/i18n!epi/cms/nls/commerce.components.pricingoverview",
// Widgets in the template
    "epi-cms/contentediting/StandardToolbar",
    "../widget/PricingOverview"
], function (
// dojo
    declare,
// commerce
    _OverviewBase,
// resources
    template,
    resources
) {
    return declare([_OverviewBase], {
        // summary:
        //      This is the initializer of Price Preview.
        resources: resources,

        templateString: template
    });
});
